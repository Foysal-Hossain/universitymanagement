/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Examinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author C6
 */
@Service
public interface ExaminfoServ {
     List<Examinfo> findAllExaminfo();
    Examinfo saveExaminfo(Examinfo exam);
    Examinfo findById(Integer id);
    void updateExaminfo(Examinfo exam);     
    void deleteExaminfoById(Integer id);
    
}
