/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Academicyear;
import info.fish.universitymanagement.model.User;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Shawon
 */
@Service
public interface AcademicyearServ {
    List<Academicyear> findAllAcademicyear();
    Academicyear saveAcademicyear(Academicyear acy);
    Academicyear findById(Integer id);
    void updateAcademicyear(Academicyear acy);     
    void deleteAcademicyearById(Integer id);
}
