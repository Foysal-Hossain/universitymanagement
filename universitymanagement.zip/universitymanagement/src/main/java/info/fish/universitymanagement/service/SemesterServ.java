/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Semester;
import info.fish.universitymanagement.model.User;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Shawon
 */
@Service
public interface SemesterServ {
    List<Semester> findAllSemester();
    Semester saveSems(Semester sems);
    Semester findById(Integer id);
    //Semester findByName(String name);
    void updateSems(Semester sems);     
    void deleteSemsById(Integer id);
}
