/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Semestersection;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.SemesterSectionServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class SemesterSectionRep implements SemesterSectionServ {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Semestersection> findAllSection() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Semestersection> sectionlist = s.createQuery("from Semestersection").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return sectionlist;
    }

    @Override
    public Semestersection saveSection(Semestersection sec) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(sec);
        t.commit();
        s.close();
        return sec; 
    }

    @Override
    public Semestersection findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Semestersection sec = (Semestersection) s.get(Semestersection.class, id);
        t.commit();
        s.close();
        return sec;
    }

    @Override
    public void updateSection(Semestersection sec) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(sec);
        t.commit();
        s.close();
    }

    @Override
    public void deleteSectionById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Semestersection sec = (Semestersection) s.get(Semestersection.class, id);
        s.delete(sec);
        t.commit();
        s.close();
    }

}
