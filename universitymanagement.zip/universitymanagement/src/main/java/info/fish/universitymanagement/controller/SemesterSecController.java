/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Semestersection;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.SemesterSectionServ;
import info.fish.universitymanagement.service.UserService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Shawon
 */
@RestController
@RequestMapping(value = "/api/v1")
public class SemesterSecController {

    @Autowired
    private SemesterSectionServ sectionService;

    @GetMapping("/section")//ok
    public List<Semestersection> getAllSection() {
        return sectionService.findAllSection();
    }

    @PostMapping("/section")//ok
    public Semestersection createSemestersection(@RequestBody Semestersection sec) {
        return sectionService.saveSection(sec);
    }

    @GetMapping("/section/{id}")//ok
    public ResponseEntity<Semestersection> getSemestersection(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Semestersection sec = sectionService.findById(id);
        if (sec == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Semestersection>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Semestersection>(sec, HttpStatus.OK);
    }

    @DeleteMapping("/section/{id}")
    public ResponseEntity<Semestersection> deleteSemestersection(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Semestersection sec = sectionService.findById(id);
        if (sec == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Semestersection>(HttpStatus.NOT_FOUND);
        }

        sectionService.deleteSectionById(id);
        return new ResponseEntity<Semestersection>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/section/{id}")
    public ResponseEntity<Semestersection> updateUser(@PathVariable("id") Integer id, @RequestBody Semestersection sec) {
        System.out.println("Updating User " + id);

        Semestersection currentSec = sectionService.findById(id);

        if (currentSec == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Semestersection>(HttpStatus.NOT_FOUND);
        }

        currentSec.setSectionname(sec.getSectionname());
        currentSec.setSemesterid(sec.getSemesterid());
        currentSec.setSemestername(sec.getSemestername());
        currentSec.setSemesterstatus(sec.getSemesterstatus());
        currentSec.setSectionid(sec.getSectionid());
     

        sectionService.updateSection(sec);
        return new ResponseEntity<Semestersection>(currentSec, HttpStatus.OK);
    }

}
