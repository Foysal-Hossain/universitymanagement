/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Subjects;
import info.fish.universitymanagement.model.User;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Shawon
 */
@Service
public interface SubjectsService {
    List<Subjects> findAllSubjects();
    Subjects saveSubjects(Subjects sub);
    Subjects findById(Integer id);
    void updateSubjects(Subjects sub);     
    void deleteSubjectsById(Integer id);
}
