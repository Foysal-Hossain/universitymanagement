/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Studregistration;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.StudregistrationServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class StudregistrationRep implements StudregistrationServ{
    @Autowired
    SessionFactory sessionFactory;
    
    @Override
    public List<Studregistration> findAllStudregistration() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Studregistration> registerdlist = s.createQuery("from Studregistration").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return registerdlist; 
    }

    @Override
    public Studregistration saveStudregistration(Studregistration studreg) {
        
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(studreg);
        t.commit();
        s.close();
        return studreg;
    }

    @Override
    public Studregistration findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studregistration studreg = (Studregistration) s.get(Studregistration.class, id);
        t.commit();
        s.close();
        return studreg;
    }

    @Override
    public void updateStudregistration(Studregistration studreg) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(studreg);
        t.commit();
        s.close();
    }

    @Override
    public void deleteStudregistrationById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studregistration studreg = (Studregistration) s.get(Studregistration.class, id);
        s.delete(studreg);
        t.commit();
        s.close();
    }
    
}
