/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Exammarks;
import info.fish.universitymanagement.service.ExammarksServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author C6
 */
@Repository
public class ExammarksRep implements ExammarksServ {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Exammarks> findAllMarks() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Exammarks> marklist = s.createQuery("from Exammarks").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return marklist;
    }

    @Override
    public Exammarks saveExammarks(Exammarks mark) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(mark);
        t.commit();
        s.close();
        return mark;
    }

    @Override
    public Exammarks findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Exammarks marks = (Exammarks) s.get(Exammarks.class, id);
        t.commit();
        s.close();
        return marks;
    }

    @Override
    public void updateExammarks(Exammarks mark) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(mark);
        t.commit();
        s.close();
    }

    @Override
    public void deleteExammarksById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Exammarks marks = (Exammarks) s.get(Exammarks.class, id);
        s.delete(marks);
        t.commit();
        s.close();
    }

}
