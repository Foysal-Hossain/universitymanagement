/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Examinfo;
import info.fish.universitymanagement.service.ExaminfoServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author C6
 */
@Repository
public class ExaminfoRep implements ExaminfoServ{
    @Autowired
    SessionFactory sessionFactory;
    
    @Override
    public List<Examinfo> findAllExaminfo() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Examinfo> examlist = s.createQuery("from Examinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return examlist;
    }

    @Override
    public Examinfo saveExaminfo(Examinfo exam) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(exam);
        t.commit();
        s.close();
        return exam;
    }

    @Override
    public Examinfo findById(Integer id) {
      Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Examinfo exam = (Examinfo) s.get(Examinfo.class, id);
        t.commit();
        s.close();
        return exam;
    }

    @Override
    public void updateExaminfo(Examinfo exam) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(exam);
        t.commit();
        s.close();
    }

    @Override
    public void deleteExaminfoById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Examinfo exam = (Examinfo) s.get(Examinfo.class, id);
        s.delete(exam);
        t.commit();
        s.close();
    }
    
}
