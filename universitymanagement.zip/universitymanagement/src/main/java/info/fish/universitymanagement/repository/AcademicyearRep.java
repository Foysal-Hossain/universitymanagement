/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Academicyear;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.AcademicyearServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class AcademicyearRep implements AcademicyearServ{
    @Autowired
    SessionFactory sessionFactory;
    
    @Override
    public List<Academicyear> findAllAcademicyear() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Academicyear> acylist = s.createQuery("from Academicyear").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return acylist;
    }

    @Override
    public Academicyear saveAcademicyear(Academicyear acy) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(acy);
        t.commit();
        s.close();
        return acy;
        
    }

    @Override
    public Academicyear findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Academicyear acy = (Academicyear) s.get(Academicyear.class, id);
        t.commit();
        s.close();
        return acy;
    }

    @Override
    public void updateAcademicyear(Academicyear acy) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(acy);
        t.commit();
        s.close();
    }

    @Override
    public void deleteAcademicyearById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Academicyear acy = (Academicyear) s.get(Academicyear.class, id);
        s.delete(acy);
        t.commit();
        s.close();
    }
    
}
