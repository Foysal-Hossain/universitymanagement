/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Semester;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.SemesterServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class SemesterRep implements SemesterServ {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Semester> findAllSemester() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Semester> semsterlist = s.createQuery("from Semester").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return semsterlist;
    }

    @Override
    public Semester saveSems(Semester sems) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(sems);
        t.commit();
        s.close();
        return sems;
    }

    @Override
    public Semester findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Semester sems = (Semester) s.get(Semester.class, id);
        t.commit();
        s.close();
        return sems;
    }

    @Override
    public void updateSems(Semester sems) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(sems);
        t.commit();
        s.close();
    }

    @Override
    public void deleteSemsById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Semester sems = (Semester) s.get(Semester.class, id);
        s.delete(sems);
        t.commit();
        s.close();
    }

}
