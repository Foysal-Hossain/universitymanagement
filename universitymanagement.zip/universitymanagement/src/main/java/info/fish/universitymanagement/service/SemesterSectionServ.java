/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Semestersection;
import info.fish.universitymanagement.model.User;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Shawon
 */
@Service
public interface SemesterSectionServ {
    List<Semestersection> findAllSection();
    Semestersection saveSection(Semestersection sec);
    Semestersection findById(Integer id);
    void updateSection(Semestersection sec);     
    void deleteSectionById(Integer id);
}
