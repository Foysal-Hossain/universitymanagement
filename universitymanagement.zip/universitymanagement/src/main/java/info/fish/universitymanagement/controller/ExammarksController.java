/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Exammarks;
import info.fish.universitymanagement.service.ExammarksServ;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author C6
 */
@RestController
@RequestMapping(value = "/api/v1")
public class ExammarksController {

    @Autowired
    private ExammarksServ marksService;

    @GetMapping("/marks")//ok
    public List<Exammarks> getAllExammarks() {
        return marksService.findAllMarks();
    }

    @PostMapping("/marks")//ok
    public Exammarks createExammarks(@RequestBody Exammarks marks) {
        return marksService.saveExammarks(marks);
    }

    @GetMapping("/marks/{id}")//ok
    public ResponseEntity<Exammarks> getExammarks(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Exammarks marks = marksService.findById(id);
        if (marks == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Exammarks>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Exammarks>(marks, HttpStatus.OK);
    }

    @DeleteMapping("/marks/{id}")
    public ResponseEntity<Exammarks> deleteExammarks(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Exammarks marks = marksService.findById(id);
        if (marks == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Exammarks>(HttpStatus.NOT_FOUND);
        }

        marksService.deleteExammarksById(id);
        return new ResponseEntity<Exammarks>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/marks/{id}")
    public ResponseEntity<Exammarks> updateExammarks(@PathVariable("id") Integer id, @RequestBody Exammarks marks) {
        System.out.println("Updating User " + id);

        Exammarks currentExammarks = marksService.findById(id);

        if (currentExammarks == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Exammarks>(HttpStatus.NOT_FOUND);
        }

        currentExammarks.setDepartmentid(marks.getDepartmentid());
        currentExammarks.setExamid(marks.getExamid());
     
        currentExammarks.setMarkid(marks.getMarkid());
        currentExammarks.setSemesterid(marks.getSemesterid());
        currentExammarks.setStudentid(marks.getStudentid());
        currentExammarks.setSectionid(marks.getSectionid());
        currentExammarks.setSubid(marks.getSubid());
        currentExammarks.setMarkobtained(marks.getMarkobtained());
           currentExammarks.setMarkgrade(marks.getMarkgrade());
        currentExammarks.setYearid(marks.getYearid());

   

        marksService.updateExammarks(currentExammarks);
        return new ResponseEntity<Exammarks>(currentExammarks, HttpStatus.OK);
    }

}
