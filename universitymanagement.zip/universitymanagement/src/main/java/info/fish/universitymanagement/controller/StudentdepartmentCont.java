/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Studentdepartment;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.StudentdepartmentServ;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Shawon
 */
@RestController
@RequestMapping(value = "/api/v1")
public class StudentdepartmentCont {

    @Autowired
    private StudentdepartmentServ deptService;

    @GetMapping("/dept")//ok
    public List<Studentdepartment> getAllStudentdepartment() {
        return deptService.findAllDep();
    }

    @PostMapping("/dept")//ok
    public Studentdepartment createStudentdepartment(@RequestBody Studentdepartment dept) {
        return deptService.saveStudentdepartment(dept);
    }

    @GetMapping("/dept/{id}")//ok
    public ResponseEntity<Studentdepartment> getStudentdepartment(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Studentdepartment dept = deptService.findById(id);
        if (dept == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Studentdepartment>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Studentdepartment>(dept, HttpStatus.OK);
    }

    @DeleteMapping("/dept/{id}")
    public ResponseEntity<Studentdepartment> deleteStudentdepartment(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Studentdepartment dept = deptService.findById(id);
        if (dept == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Studentdepartment>(HttpStatus.NOT_FOUND);
        }

        deptService.deleteStudentdepartmentById(id);
        return new ResponseEntity<Studentdepartment>(HttpStatus.NO_CONTENT);
    }

    @PutMapping("/dept/{id}")
    public ResponseEntity<Studentdepartment> updateStudentdepartment(@PathVariable("id") Integer id, @RequestBody Studentdepartment dept) {
        System.out.println("Updating User " + id);

        Studentdepartment currentdept = deptService.findById(id);

        if (currentdept == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Studentdepartment>(HttpStatus.NOT_FOUND);
        }

        currentdept.setDepartmentname(dept.getDepartmentname());
        currentdept.setDepartmentstatus(dept.getDepartmentstatus());
        currentdept.setDepartmentid(dept.getDepartmentid());

        deptService.updateStudentdepartment(currentdept);
        return new ResponseEntity<Studentdepartment>(currentdept, HttpStatus.OK);
    }

}
