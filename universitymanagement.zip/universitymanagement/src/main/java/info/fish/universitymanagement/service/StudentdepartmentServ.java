/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Studentdepartment;
import info.fish.universitymanagement.model.User;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author Shawon
 */
@Service
public interface StudentdepartmentServ {
    List<Studentdepartment> findAllDep();
    Studentdepartment saveStudentdepartment(Studentdepartment dept);
    Studentdepartment findById(Integer id);
    //Studentdepartment findNameById(String name);
    //Studentdepartment findIdByName(Integer id);
    void updateStudentdepartment(Studentdepartment dept);     
    void deleteStudentdepartmentById(Integer id);
}
