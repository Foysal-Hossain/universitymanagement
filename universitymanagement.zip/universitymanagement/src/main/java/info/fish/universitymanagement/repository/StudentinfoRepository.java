/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Studentinfo;
import info.fish.universitymanagement.model.User;

import info.fish.universitymanagement.service.StudentinfoService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class StudentinfoRepository implements StudentinfoService {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Studentinfo> findAllStudent() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Studentinfo> studentlist = s.createQuery("from Studentinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return studentlist;
    }

    @Override
    public Studentinfo saveStudentinfo(Studentinfo studinfo) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(studinfo);
        t.commit();
        s.close();
        return studinfo;
    }

    @Override
    public Studentinfo findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studentinfo studinfo = (Studentinfo) s.get(Studentinfo.class, id);
        t.commit();
        s.close();
        return studinfo;
    }

    @Override
    public void updateStudent(Studentinfo studinfo) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(studinfo);
        t.commit();
        s.close();
    }

    @Override
    public void deleteStudentById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studentinfo studinfo = (Studentinfo) s.get(Studentinfo.class, id);
        s.delete(studinfo);
        t.commit();
        s.close();
    }

}
