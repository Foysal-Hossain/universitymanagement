/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Semester;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.SemesterServ;
import info.fish.universitymanagement.service.UserService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Shawon
 */
@RestController
@RequestMapping(value = "/api/v1")
public class SemsterController {

    @Autowired
    private SemesterServ semsService;

    @GetMapping("/semester")//ok
    public List<Semester> getAllSemester() {
        return semsService.findAllSemester();
    }

    @PostMapping("/semester")//ok
    public Semester createSemester(@RequestBody Semester sem) {
        return semsService.saveSems(sem);
    }

    @GetMapping("/semester/{id}")//ok
    public ResponseEntity<Semester> getSemester(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Semester sems = semsService.findById(id);
        if (sems == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Semester>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Semester>(sems, HttpStatus.OK);
    }
    
      @PutMapping("/semester/{id}")
    public ResponseEntity<Semester> updateSemester(@PathVariable("id") Integer id, @RequestBody Semester sems) {
        System.out.println("Updating User " + id);

        Semester currentSems = semsService.findById(id);

        if (currentSems == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Semester>(HttpStatus.NOT_FOUND);
        }
        currentSems.setSemestername(sems.getSemestername());
        currentSems.setSemesterid(sems.getSemesterid());
        semsService.updateSems(currentSems);
        return new ResponseEntity<Semester>(currentSems, HttpStatus.OK);
    }
    
      @DeleteMapping("/semester/{id}")
    public ResponseEntity<Semester> deleteSemester(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Semester sems = semsService.findById(id);
        if (sems == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Semester>(HttpStatus.NOT_FOUND);
        }

        semsService.deleteSemsById(id);
        return new ResponseEntity<Semester>(HttpStatus.NO_CONTENT);
    }
    
    
    
}
