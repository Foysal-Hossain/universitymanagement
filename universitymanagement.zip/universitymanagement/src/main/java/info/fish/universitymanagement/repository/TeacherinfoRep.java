/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Teacherinfo;
import info.fish.universitymanagement.service.TeacherinfoServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author C6
 */
@Repository
public class TeacherinfoRep implements TeacherinfoServ {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Teacherinfo> findAllTeacher() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Teacherinfo> teacherlist = s.createQuery("from Teacherinfo").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return teacherlist;
    }

    @Override
    public Teacherinfo saveTeacherinfo(Teacherinfo teacher) {

        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(teacher);
        t.commit();
        s.close();
        return teacher;
    }

    @Override
    public Teacherinfo findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Teacherinfo teacher = (Teacherinfo) s.get(Teacherinfo.class, id);
        t.commit();
        s.close();
        return teacher;
    }

    @Override
    public void updateTeacherinfo(Teacherinfo teacher) {
         Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(teacher);
        t.commit();
        s.close();
    }

    @Override
    public void deleteTeacherinfoById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Teacherinfo teacher = (Teacherinfo) s.get(Teacherinfo.class, id);
        s.delete(teacher);
        t.commit();
        s.close();
    }


}
