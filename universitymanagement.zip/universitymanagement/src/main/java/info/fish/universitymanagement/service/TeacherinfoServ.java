/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Teacherinfo;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author C6
 */
@Service
public interface TeacherinfoServ {
    
    List<Teacherinfo> findAllTeacher();
    Teacherinfo saveTeacherinfo(Teacherinfo teacher);
    Teacherinfo findById(Integer id);
    void updateTeacherinfo(Teacherinfo teacher);     
    void deleteTeacherinfoById(Integer id);
    
}
