/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Studentdepartment;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.StudentdepartmentServ;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class StudentdepartmentRep implements StudentdepartmentServ {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<Studentdepartment> findAllDep() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Studentdepartment> deplist = s.createQuery("from Studentdepartment").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return deplist;
    }

    @Override
    public Studentdepartment saveStudentdepartment(Studentdepartment dept) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(dept);
        t.commit();
        s.close();
        return dept;
    }

    @Override
    public Studentdepartment findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studentdepartment dept = (Studentdepartment) s.get(Studentdepartment.class, id);
        t.commit();
        s.close();
        return dept;
    }

    @Override
    public void updateStudentdepartment(Studentdepartment dept) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(dept);
        t.commit();
        s.close();
    }

    @Override
    public void deleteStudentdepartmentById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Studentdepartment dept = (Studentdepartment) s.get(Studentdepartment.class, id);
        s.delete(dept);
        t.commit();
        s.close();
    }

}
