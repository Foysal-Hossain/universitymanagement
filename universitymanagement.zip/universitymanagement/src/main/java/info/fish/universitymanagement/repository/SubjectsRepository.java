/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.Subjects;
import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.SubjectsService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Shawon
 */
@Repository
public class SubjectsRepository implements SubjectsService{
    @Autowired
    SessionFactory sessionFactory;
    
    
    @Override
    public List<Subjects> findAllSubjects() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<Subjects> sublist = s.createQuery("from Subjects").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return sublist;
    }

    @Override
    public Subjects saveSubjects(Subjects sub) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(sub);
        t.commit();
        s.close();
        return sub;
    }

    @Override
    public Subjects findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Subjects sub = (Subjects) s.get(Subjects.class, id);
        t.commit();
        s.close();
        return sub;
    }

    @Override
    public void updateSubjects(Subjects sub) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(sub);
        t.commit();
        s.close(); 
    }

    @Override
    public void deleteSubjectsById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        Subjects sub = (Subjects) s.get(Subjects.class, id);
        s.delete(sub);
        t.commit();
        s.close(); 
    }
    
}
