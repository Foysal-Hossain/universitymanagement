/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Teacherinfo;
import info.fish.universitymanagement.service.TeacherinfoServ;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author C6
 */
@RestController
@RequestMapping(value="/api/v1")
public class TeacherinfoController {
    
     @Autowired
    private TeacherinfoServ teacherService;
     
    @GetMapping("/teacher")//ok
    public List<Teacherinfo> getAllTeacherinfo() {
        return teacherService.findAllTeacher();
    }
    
     @PostMapping("/teacher")//ok
    public Teacherinfo createTeacherinfo(@RequestBody Teacherinfo teacher) {
        return teacherService.saveTeacherinfo(teacher);
    }
    
     @GetMapping("/teacher/{id}")//ok
    public ResponseEntity<Teacherinfo> getTeacherinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Teacherinfo teacher = teacherService.findById(id);
        if (teacher == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Teacherinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Teacherinfo>(teacher, HttpStatus.OK);
    }
    
     @DeleteMapping("/teacher/{id}")
    public ResponseEntity<Teacherinfo> deleteTeacherinfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Teacherinfo teacher = teacherService.findById(id);
        if (teacher == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Teacherinfo>(HttpStatus.NOT_FOUND);
        }

        teacherService.deleteTeacherinfoById(id);
        return new ResponseEntity<Teacherinfo>(HttpStatus.NO_CONTENT);
    }
    
    
    @PutMapping("/teacher/{id}")
    public ResponseEntity<Teacherinfo> updateTeacherinfo(@PathVariable("id") Integer id, @RequestBody Teacherinfo teacher) {
        System.out.println("Updating User " + id);

        Teacherinfo currentTeacher = teacherService.findById(id);

        if (currentTeacher == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Teacherinfo>(HttpStatus.NOT_FOUND);
        }

        currentTeacher.setTeachername(teacher.getTeachername());
        currentTeacher.setDepartmentid(teacher.getDepartmentid());
        currentTeacher.setTeachergender(teacher.getTeachergender());
        currentTeacher.setEmail(teacher.getEmail());
        currentTeacher.setTeacheraddress(teacher.getTeacheraddress());
        currentTeacher.setTeacherstatus(teacher.getTeacherstatus());
        currentTeacher.setSubid(teacher.getSubid());
        currentTeacher.setTeachercontact(teacher.getTeachercontact());
        currentTeacher.setTjoindate(teacher.getTjoindate());
        currentTeacher.setTeacherid(teacher.getTeacherid());

     

        teacherService.updateTeacherinfo(currentTeacher);
        return new ResponseEntity<Teacherinfo>(currentTeacher, HttpStatus.OK);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
