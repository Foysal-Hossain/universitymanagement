/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.service;

import info.fish.universitymanagement.model.Exammarks;
import java.util.List;
import org.springframework.stereotype.Service;

/**
 *
 * @author C6
 */
@Service
public interface ExammarksServ {
     List<Exammarks> findAllMarks();
    Exammarks saveExammarks(Exammarks mark);
    Exammarks findById(Integer id);
    void updateExammarks(Exammarks mark);     
    void deleteExammarksById(Integer id);
    
}
