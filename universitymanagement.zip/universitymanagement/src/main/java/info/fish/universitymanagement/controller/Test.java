/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Shawon
 */
@Controller
public class Test {
    
    @RequestMapping(value = "/")
    public String welcome(){
        return "index";
    }
    
}
