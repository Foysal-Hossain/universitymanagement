/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.repository;

import info.fish.universitymanagement.model.User;
import info.fish.universitymanagement.service.UserService;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author C6
 */
@Repository
public class UserRepository implements UserService {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public List<User> findAllUsers() {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        List<User> userlist = s.createQuery("from User").list();
        t.commit();
        s.close();
        //System.out.println(categorylistgson);
        return userlist;
    }

    @Override
    public User saveUser(User user) {

        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        s.save(user);
        t.commit();
        s.close();
        return user;
    }

    @Override
    public User findById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        User user = (User) s.get(User.class, id);
        t.commit();
        s.close();
        return user;
    }

    @Override
    public void updateUser(User user) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        //CategoriesModel cm = (CategoriesModel)s.get(CategoriesModel.class, categoryid);
        s.update(user);
        t.commit();
        s.close();
    }

    @Override
    public void deleteUserById(Integer id) {
        Session s = sessionFactory.openSession();
        Transaction t = s.getTransaction();
        t.begin();
        User user = (User) s.get(User.class, id);
        s.delete(user);
        t.commit();
        s.close();
    }

}
