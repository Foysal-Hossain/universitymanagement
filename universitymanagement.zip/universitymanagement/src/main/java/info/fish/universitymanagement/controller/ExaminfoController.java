/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package info.fish.universitymanagement.controller;

import info.fish.universitymanagement.model.Examinfo;
import info.fish.universitymanagement.service.ExaminfoServ;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author C6
 */
@RestController
@RequestMapping(value="/api/v1")
public class ExaminfoController {
    
    @Autowired
    private ExaminfoServ examService;
    
    
   @GetMapping("/exam")//ok
    public List<Examinfo> getAllExaminfo() {
        return examService.findAllExaminfo();
    }
    
     @PostMapping("/exam")//ok
    public Examinfo createExaminfo(@RequestBody Examinfo exam) {
        return examService.saveExaminfo(exam);
    }
    
     @GetMapping("/exam/{id}")//ok
    public ResponseEntity<Examinfo> getExaminfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching User with id " + id);
        Examinfo exam = examService.findById(id);
        if (exam == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Examinfo>(HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<Examinfo>(exam, HttpStatus.OK);
    }
    
    
    @DeleteMapping("/exam/{id}")
    public ResponseEntity<Examinfo> deleteExaminfo(@PathVariable("id") Integer id) {
        System.out.println("Fetching & Deleting User with id " + id);

        Examinfo exam = examService.findById(id);
        if (exam == null) {
            System.out.println("Unable to delete. User with id " + id + " not found");
            return new ResponseEntity<Examinfo>(HttpStatus.NOT_FOUND);
        }

        examService.deleteExaminfoById(id);
        return new ResponseEntity<Examinfo>(HttpStatus.NO_CONTENT);
    }
    
    
      @PutMapping("/exam/{id}")
    public ResponseEntity<Examinfo> updateExaminfo(@PathVariable("id") Integer id, @RequestBody Examinfo exam) {
        System.out.println("Updating User " + id);

        Examinfo currentExaminfo = examService.findById(id);

        if (currentExaminfo == null) {
            System.out.println("User with id " + id + " not found");
            return new ResponseEntity<Examinfo>(HttpStatus.NOT_FOUND);
        }

        currentExaminfo.setDepartmentid(exam.getDepartmentid());
        currentExaminfo.setExamid(exam.getExamid());
        currentExaminfo.setDescription(exam.getDescription());
        currentExaminfo.setExamtype(exam.getExamtype());
        currentExaminfo.setSubid(exam.getSubid());
        currentExaminfo.setExamdate(exam.getExamdate());
        currentExaminfo.setTeacherid(exam.getTeacherid());
      
        examService.updateExaminfo(currentExaminfo);
        return new ResponseEntity<Examinfo>(currentExaminfo, HttpStatus.OK);
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
